import React from "react";
import "./css/headerfood.css";
function Head(){
    
    return(
        <div className="my-4" >
           
            <h1>Get your pet's<span className="header"> food</span></h1>
          
        </div>
    )
}
export default Head