import React from "react";
import "./css/header.css";
function Header() {

    return(
        <div className="my-4" >
           
            <h1>Adopt Your<span className="header"> Pet</span></h1>
          
        </div>
    )
}

export default Header