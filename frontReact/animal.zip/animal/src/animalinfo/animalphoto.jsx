import React from "react";
function Imag(props){
    return(
        <div>
             <img src={props.image} class="card-img-top" alt="..."/>
        </div>
    )
}
export default Imag