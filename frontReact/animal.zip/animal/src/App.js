import logo from './logo.svg';
import './App.css';
import Animalpage from './animal/animalpage';
import'bootstrap/dist/css/bootstrap.min.css';
import'bootstrap/dist/js/bootstrap.min.js';
import Info from './animalinfo/animalinfo';
import Foodpage from './food/foodpage';
//import Foodpage from './foodpage/foodpage';
function App() {
  return (
  //<Animalpage />
 // <Info/>
  <Foodpage/>
  );
}

export default App;
